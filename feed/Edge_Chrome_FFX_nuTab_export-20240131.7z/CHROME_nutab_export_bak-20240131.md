# w社\_ROGPC2306 CHROME-WORKSYNC 2024/01-24

* * *

\[x\] online

* [ ] **电子书搜索**介绍 [www.ahhhhfs.com/36200/](https://www.ahhhhfs.com/36200/) [www.ahhhhfs.com/45450/](https://www.ahhhhfs.com/45450/)

* [ ] [https://zh.annas-archive.org/](https://zh.annas-archive.org/) 安娜的档案 OK
* [ ] [https://zlib.pseudoyu.com/](https://zlib.pseudoyu.com/) √ OK
* [ ] [https://book-searcher.eu.org/](https://book-searcher.eu.org/) √ NG
* [ ] [https://zbook.eu.org/](https://zbook.eu.org/) √ NG
* [ ] [https://zlib.knat.network](https://zlib.knat.network) √ NG
* [ ] [Library Genesis](https://libgen.is) √ OK
* [ ] **Docker/Zbook** 自建 [47.100.11.17:8081](http://47.100.11.17:8081/) × NG
* [ ] [Libgen图书上传](https://library.bz/main/upload)（上传书籍 [https://www.libgen.is/librarian/](https://www.libgen.is/librarian/) 账户genesis 密码upload）

* * *

\[√\] Fixed-Tab

* [ ] Java综技面经 -[**MySQL**](https://tommyyang.gitbook.io/javainterview/architecture/mysql)
* [ ] [https://mirror.xyz/dashboard](https://mirror.xyz/dashboard)

* * *

**※ 以下参考/工具/案例/说明**

\[T\] **Chromium 原生开源浏览器** [https://download-chromium.appspot.com/](https://download-chromium.appspot.com/)

\[S\] **小雅的 Alist 仓库** [http://alist.xiaoya.pro/](http://alist.xiaoya.pro/) (综合/影视/音频 可独立部署Docker)

\[S\] **七米蓝的 Alist 仓库** [https://al.chirmyram.com/](https://al.chirmyram.com/) (综合/影视/工具 可挂载Webdav)

\[S\] **神族九帝的 Alist 仓库** [https://alist.shenzjd.com/](https://alist.shenzjd.com/) (软件/工具 为主)

\[S\] **梓澪的 Alist 仓** [https://zi0.cc/](https://zi0.cc/) (游戏/Emby服务/付费刮削)

\[S\]