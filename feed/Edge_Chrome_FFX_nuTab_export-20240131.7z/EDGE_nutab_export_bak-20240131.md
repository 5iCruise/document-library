# ROGPC2306 FFX-WORKSYNC 2024/01-23

→ **C**apture **T**houghts **D**ENY **L**osing **A**nything.ROGPC0701-DATA Migration

* * *

【R】日常备考 【P】项目/课题 【Q】问题/跟进/解决 【D】完成/过期 【IS】想法/闪念

*   \[[ROGPC2306 SHARING](http://192.168.18.113:8189/)\] \[[PicX图床](https://picx.darkwarrior2025.xyz)\] \[[IPFS-CHECKER](https://ipfs.github.io/public-gateway-checker)\] \[[MirrorZ.org](https://mirrorz.org/)\] **\[**[**Flow在线阅读**](https://app.flowoss.com/zh-CN)**\]**
    
*   \[WQ[磁力搜索](https://wuqianke.top)\] \[[PostImage图床](https://postimg.cc/user/icruisedata)\] \[[zBooks搜书](https://zlib.missuo.me)\] \[[鸠摩搜索](https://jiumodiary.com)\] \[[搜剧](http://abc768.com)\] \[[**RSS源**](https://rss-source.com)\]
    

【R】outineInfo-Reading Update2Notes

\[x\] 程序员职场工具库 - [**Excel 应用**](https://juejin.cn/post/7234724407611080759)

\[-\] MD写作发布站 - [ROGER.S / iCruiseNews · GitLab](https://gitlab.com/5iCruise/i-cruise-news)

\[-\] PyCharm 中文指南 - [pycharm.iswbm.com](https://pycharm.iswbm.com/index.html) 10-18

\[-\] Linux系统基础学习 - [Linux\_01-咱们从Linux安装开始说起 - 爱折腾的程序猿](https://www.katexiaohao.xyz/archives/42.html)

【P】

*   TypeScript 教程 【 [https://ts.xcatliu.com/](https://ts.xcatliu.com/) 】
    
*   NextJS博客 案例 【 [https://www.timlrx.com/](https://www.timlrx.com/) 】
    
*   如何搭建博客 【 [作为小白是怎么搭建博客的](https://veryjack.com/technique/how-to-build-blog/) 】
    
*   博客架构从 HEXO 迁移到 ASTRO 【 [迁移 Blog 到 Astro](https://blog.xinshijiededa.men/astro/migration) 】
    

*   [通过github pages+hexo搭建个人博客 - 小铭＆小宝的世界 (smartpippin.asia)](https://smartpippin.asia/posts/b036a934/) ★★☆
    

【IS】

\[-\] _TiddlyWiki_ 太微/太记 [**中文社区**](https://tw-cn.netlify.app) [**搭建案例**](https://onetwo.ren/wiki#Index:Index)**（仿用）** ★★★

\[-\] [Library — Zhiheng Lin's Second Brain](https://wiki.zhiheng.io/)

\[-\] [TiddyWiki 简易指南 (pkmer.cn)](https://pkmer.cn/Pkmer-Docs/12-tiddywiki/tiddywiki/)

\[-\] [WikiText: TiddlyWiki](https://tiddlywiki.com/static/WikiText.html)

**※** 参考资料

* [ ] 中考资料(奥孚升学) [**百度网盘更新**](https://pan.baidu.com/s/1t_QJcEkLUF-HXWhDiaqGAA?pwd=33ny) 2023-11-16
* [ ] w社港口\_**游客离港管理系统** 数据UPDATE \[ wsict ^ Ws@cruise \] ★
* [ ] CCTV13-News [LIVE视频播放器 (fanmingming.com)](https://live.fanmingming.com/player/?vurl=https://0472.org/hls/cctv13.m3u8)
* [ ] [中国历朝代视频讲解 (historyline.online)](https://www.historyline.online/)
* [ ] **AIGC应用** [two-ai-ui (qiangtu.com)](https://twoapi-ui.qiangtu.com/)

* * *

**※ 以下参考/工具/案例/说明**

\[F\]爱发电 [https://afdian.net/@DarkWarrior2025](https://afdian.net/@DarkWarrior2025) (#打赏/会员服务)

\[B\]刘未鹏MindHacks [http://mindhacks.cn/](http://mindhacks.cn/) (#Blog)(独立思考)

\[B\]P/D的知识博客 [https://blog.zhheo.com/](https://blog.zhheo.com/) (#Blog)

\[B\]ljf博客 [https://ljf.com/archives/](https://ljf.com/archives/) (#Blog)(阅读/笔记)★★☆

\[B\]魚立说 [https://www.yulisay.com/](https://www.yulisay.com/) (#Blog)

\[B\]P小二 [https://pxiaoer.blog/](https://pxiaoer.blog/) (#Blog)（B站SPACE）

\[B\]王下邀月熊 [https://ng-tech.icu/](https://ng-tech.icu/) (#Blog/Note)(开源站) ★★★

\[B\]Junming [https://jm199504.github.io/](https://jm199504.github.io/) (#Blog/Python/Fintech)

\[I\]FlowChart [https://flowchart.fun/](https://flowchart.fun/) (#SVG流图 生成)

\[I\]VShareTool [https://vshare.tools/index.php/apps/dashboard/](https://vshare.tools/index.php/apps/dashboard/) (#File管理)

\[I\]Linear.app [https://linear.app/dw2025/team/DW2/active](https://linear.app/dw2025/team/DW2/active) (#Issue管理)

\[I\]Whimsical [https://whimsical.com/](https://whimsical.com/) (Docs/WireFrames Web设计管理)

\[B\]不点语书(思考自留地) [https://yjalifebook.com/](https://yjalifebook.com/) (#Blog)

\[B\]安志合学习博客 [https://chegva.com/](https://chegva.com/) (#Blog)

\[B\]Hugo中实现豆瓣条目 [https://mantyke.icu/2021/e7cf079c/](https://mantyke.icu/2021/e7cf079c/) (#Blog)

\[B\]行运设计师(Github) [https://www.luckydesigner.space/](https://www.luckydesigner.space/) (#Blog)

\[I\]播客 Feed 集中订阅 [https://getpodcast.xyz/](https://getpodcast.xyz/) (#PodCast)

\[I\]个人桌面展示/桌布定制 [https://deskto.ps/](https://deskto.ps/) [https://colorfu.art/editor](https://colorfu.art/editor) (#在线用)

\[B\]AdmCPR [https://admcpr.com/](https://admcpr.com/) (#Blog)(Github)

\[B\]正版乔 [https://blog.feelyou.top/](https://blog.feelyou.top/) (#Blog)(ISBN图书采集)(Github)

\[B\]椒盐鸵鸟 [https://blog.douchi.space/](https://blog.douchi.space/) (#Blog)(思考)

\[S\]F搜社区 [https://nilmap.com/](https://nilmap.com/) (#SearchEngineDev)(搜索开发)

\[B\]Lisa Ding [https://dinglisa.com/blog/](https://dinglisa.com/blog/) (#Blog)(个人思考)

\[B\]Keep Coding [https://liujiacai.net/](https://liujiacai.net/) (#Blog)(PodCast 搭建)

\[B\]Power's Digest [https://digest.wiki-power.com/](https://digest.wiki-power.com/) (#Blog)(阅读笔记) ★★☆

\[B\]LARRY的午茶時光 [https://blog.yuyansoftware.com.tw/](https://blog.yuyansoftware.com.tw/) (#Blog)(商業、美食、閱讀)

\[B\]CHRISON的目的地 [https://blog.chrison.cn/](https://blog.chrison.cn/) (#Blog)(生活、文化)

\[B\]刘家财的个人博客 [https://liujiacai.net/](https://liujiacai.net/) (#Blog)(技术、播客、PL、RUST、DevOps)

\[B\]博客：[木木木木木](https://immmmm.com) [https://immmmm.com/posts/coding/](https://immmmm.com/posts/coding/) (#Blog)(技术、博客)

\[B\]夜未央的个人博客 [https://www.savouer.com/](https://www.savouer.com/) (#Blog)(生活、经济、阅读)

\[B\]404 博客 [https://evan.beee.top/](https://evan.beee.top/) (#Blog)(技术、项目）

\[B\]VeryJack 播客 [https://veryjack.com/](https://veryjack.com/) (#Blog)(技术、日常、个人）★☆☆

\[B\][Jerkwin](https://jerkwin.github.io/) 哲·科·文 [https://jerkwin.github.io/](https://jerkwin.github.io/) (#Blog)(科学、GROMACS、个人、美国)

\[B\][新世界的大门 (xinshijiededa.men)](https://blog.xinshijiededa.men/) (#Blog)(技术、日常、个人）

\[I\][Three.js – JavaScript 3D Library (threejs.org)](https://threejs.org/) (#Tech)(JS前端、动画设计)

\[W\]子舒的周刊[Weekly (Zishu.me)](https://weekly.zishu.me/guide/) \[[**github.com/zishume/weekly/**](https://github.com/zishume/weekly/)\] (#Blog)(个人、阅读、)

\[B\][产品沉思录 ｜Product Thinking (notion.so)](https://www.notion.so/Product-Thinking-a601a12335044f349a22caf57f274c27)

\[B\]Wsine Blog [https://blog.wsine.top/](https://blog.wsine.top/) (#Blog)(技术、日常、个人)

\[T\]品牌图标库 [https://simpleicons.org/](https://simpleicons.org/) (#Resource)

\[B\][雪饼的狗窝 (zhouxuebin.club)](http://www.zhouxuebin.club/blog/) (#Blog)(技术、次元、AIGC)

\[R\][Calibre-Web | 书籍 (mastergo.life)](https://read.mastergo.life/) (#Read)(Calibre搭建的在线书库) ★★☆

\[K\]CIO之家文库 [CIO知识库 信息化文档](http://wenku.ciozj.com/) dw9527^Kb1245780. (#Read)(CIO、架构、文档)

\[B\]夜梦星尘 | 折腾日记 [https://tech.yemengstar.com/](https://tech.yemengstar.com/) (#Blog)(#Tech)

\[R\]DuelPeak 发现 Web 之美 [https://www.duelpeak.com/](https://www.duelpeak.com/) (#Read)(Web、App、Design)

\[B\]hsfzxjy 博客 [https://i.hsfzxjy.site/](https://i.hsfzxjy.site/) (#Blog)(Web、Coding、Life、Style)

\[B\]Sam的小窝 [https://www.samrainhan.com/](https://www.samrainhan.com/) (#Blog)(Web、Life、Style)

\[B\][佐仔志 | I try to make it simple! (jinbo123.com)](https://www.jinbo123.com/) (#Blog)(Web、Tech、Style)

\[M\][OdinSay (qiangtu.com)](https://memos.qiangtu.com/explore) (#MiniBlog)(Web、Life、Style)

\[B\][Doiiars的博客，分享有关ChatGPT、Docker、Python、机器人和有关读书阅读的内容。](https://notion.doiiars.com/)(#Blog)(Web、Tech、Style)

**※ ARCHIVE**

\[x\] [AudioMemoOutput\_2023 (notion.so)](https://www.notion.so/icruisework/AudioMemoOutput_2023-4ed58f383a2c4098ae7a0674076e244a) → MemoAI 导出 ★★☆

\[★\] 小雅的分类Alist [https://alist.xiaoya.pro/](https://alist.xiaoya.pro/) → 影视资料 等 ★★☆

\[★\] 七米蓝的Alist仓 [https://al.chirmyram.com/](https://al.chirmyram.com/) → 影视[**图书**](https://vcdoc.chirmyram.com/zh-CN) 可挂载Webdav [**gh托管**](https://github.com/ChirmyRam/ChirmyRam-OneDrive-Repository)

\[★\] Kenvie的Alist仓 [https://ali.kenvie.com/](https://ali.kenvie.com/) → 影视工具

\[√\] TV综合吧 韩剧更新同步 [【汇总】自压1080P无标中字（完结）更新 (kdocs.cn)](https://www.kdocs.cn/l/sqg0XCnR1xfW)

\[-\] Internet Radio [https://radiolise.gitlab.io/](https://radiolise.gitlab.io/)

\[-\] [云铺子 - 百度网盘搜索引擎 (yunpz.net)](https://www.yunpz.net/)

\[-\] [PanSearch | 网盘资源搜索 | 网盘搜索引擎](https://www.pansearch.me/)

\[x\] [**百度智能云**](https://console.bce.baidu.com/qianfan/overview)**千帆大模型平台** [**火山引擎**](https://console.volcengine.com/home)**（抖音）**

\[★\] [盒子地窖 (wmsio.cn)](http://www.wmsio.cn/)

\[★\] 微软全家桶激活脚本 [https://massgrave.dev/](https://massgrave.dev/)

\[-\] 盘友圈（阿里/百度/夸克） [https://panyq.com/](https://panyq.com/)

\[-\] [白噪音](https://defonic.com) + [Melofi](https://melofi.app) | [熊猫速读](https://qread.xmsoushu.com) | [小鱼速读](http://xysudu.com)

\[√\] [**值得一读技术博客**](https://daily-blog.chlinlearn.top)【RSS可订阅 每日更新】